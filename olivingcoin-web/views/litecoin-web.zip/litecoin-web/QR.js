
    $(document).ready(function(){
        $("#paybutton").click(function(){
            $("#QRpopup").fadeIn();
        });
        $("#QRpopup").click(function(){
            $("#QRpopup").fadeOut();
        });
    });

